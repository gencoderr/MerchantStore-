
import React from 'react';
import type { Product } from '../types';
import { ProductStatus } from '../types';

interface ProductCardProps {
  product: Product;
  onSelect: () => void;
}

const statusStyles: Record<ProductStatus, { bg: string; text: string; dot: string }> = {
  [ProductStatus.ACTIVE]: { bg: 'bg-green-100', text: 'text-green-800', dot: 'bg-brand-green' },
  [ProductStatus.PENDING]: { bg: 'bg-yellow-100', text: 'text-yellow-800', dot: 'bg-brand-yellow' },
  [ProductStatus.DISAPPROVED]: { bg: 'bg-red-100', text: 'text-red-800', dot: 'bg-brand-red' },
};

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const { bg, text, dot } = statusStyles[product.status] || statusStyles[ProductStatus.PENDING];

  return (
    <div
      onClick={onSelect}
      className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 animate-fade-in"
    >
      <div className="w-full h-48 bg-slate-200">
        <img src={product.imageUrl} alt={product.title} className="w-full h-full object-cover" />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-slate-800 truncate" title={product.title}>
          {product.title}
        </h3>
        <p className="text-slate-600 mt-2 font-bold text-xl">
          {new Intl.NumberFormat('en-US', { style: 'currency', currency: product.currency }).format(product.price)}
        </p>
        <div className={`mt-4 inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${bg} ${text}`}>
          <span className={`w-2 h-2 mr-2 rounded-full ${dot}`}></span>
          {product.status}
        </div>
      </div>
    </div>
  );
};
