
import React from 'react';

interface LoadingSpinnerProps {
  size?: 'small' | 'medium' | 'large';
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ size = 'medium' }) => {
  const sizeClasses = {
    small: 'w-5 h-5 border-2',
    medium: 'w-8 h-8 border-4',
    large: 'w-16 h-16 border-4',
  }[size];

  return (
    <div
      className={`${sizeClasses} border-slate-200 border-t-brand-blue rounded-full animate-spin`}
      role="status"
    >
        <span className="sr-only">Loading...</span>
    </div>
  );
};
