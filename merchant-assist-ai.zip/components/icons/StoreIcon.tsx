
import React from 'react';

interface IconProps {
  className?: string;
}

export const StoreIcon: React.FC<IconProps> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    className={className}
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5A.75.75 0 0114.25 12h.01a.75.75 0 01.75.75v7.5m-4.5 0v-7.5A.75.75 0 009.75 12h-.01a.75.75 0 00-.75.75v7.5m-4.5 0v-7.5A.75.75 0 015.25 12h.01a.75.75 0 01.75.75v7.5m-4.5 0V7.875c0-.621.504-1.125 1.125-1.125h16.5c.621 0 1.125.504 1.125 1.125v13.125m-18 0v-2.25a2.25 2.25 0 012.25-2.25h13.5a2.25 2.25 0 012.25 2.25v2.25" />
  </svg>
);
