
import React, { useState, useCallback } from 'react';
import type { Product, OptimizedListing } from '../types';
import { ProductStatus } from '../types';
import { optimizeProductListing } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { CloseIcon } from './icons/CloseIcon';
import { SparklesIcon } from './icons/SparklesIcon';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
  onProductUpdate: (product: Product) => void;
}

const statusStyles: Record<ProductStatus, { bg: string; text: string; dot: string }> = {
  [ProductStatus.ACTIVE]: { bg: 'bg-green-100', text: 'text-green-800', dot: 'bg-brand-green' },
  [ProductStatus.PENDING]: { bg: 'bg-yellow-100', text: 'text-yellow-800', dot: 'bg-brand-yellow' },
  [ProductStatus.DISAPPROVED]: { bg: 'bg-red-100', text: 'text-red-800', dot: 'bg-brand-red' },
};

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose, onProductUpdate }) => {
    const [isOptimizing, setIsOptimizing] = useState(false);
    const [optimizationError, setOptimizationError] = useState<string | null>(null);
    const [optimizedListing, setOptimizedListing] = useState<OptimizedListing | null>(null);

    const handleOptimize = useCallback(async () => {
        setIsOptimizing(true);
        setOptimizationError(null);
        setOptimizedListing(null);
        try {
            const result = await optimizeProductListing(product);
            setOptimizedListing(result);
        } catch (e) {
            setOptimizationError('Failed to optimize listing. Please try again.');
        } finally {
            setIsOptimizing(false);
        }
    }, [product]);

    const handleApplyChanges = () => {
      if(optimizedListing){
        onProductUpdate({
          ...product,
          title: optimizedListing.newTitle,
          description: optimizedListing.newDescription
        });
        setOptimizedListing(null);
      }
    };

    const { bg, text, dot } = statusStyles[product.status] || statusStyles[ProductStatus.PENDING];

  return (
    <div 
        className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto flex flex-col md:flex-row animate-slide-up"
        onClick={e => e.stopPropagation()}
      >
        <button 
            onClick={onClose} 
            className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 transition-colors z-10"
        >
            <CloseIcon className="w-6 h-6"/>
        </button>

        <div className="w-full md:w-1/2">
            <img src={product.imageUrl} alt={product.title} className="w-full h-64 md:h-full object-cover md:rounded-l-xl" />
        </div>

        <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col">
          <div className="flex-grow">
            <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${bg} ${text} mb-2`}>
              <span className={`w-2 h-2 mr-2 rounded-full ${dot}`}></span>
              {product.status}
            </div>

            <h2 className="text-3xl font-bold text-slate-800">{product.title}</h2>
            
            <p className="text-slate-700 mt-4 text-2xl font-semibold">
              {new Intl.NumberFormat('en-US', { style: 'currency', currency: product.currency }).format(product.price)}
            </p>
            
            <p className="text-slate-600 mt-4 h-32 overflow-y-auto pr-2">{product.description}</p>
          </div>
          
          <div className="mt-6 pt-6 border-t border-slate-200">
             {optimizedListing ? (
                 <div className="animate-fade-in">
                    <h3 className="font-semibold text-lg text-slate-800 mb-2">✨ AI-Optimized Listing</h3>
                    <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                        <p className="font-bold">{optimizedListing.newTitle}</p>
                        <p className="text-sm text-slate-600 mt-2">{optimizedListing.newDescription}</p>
                    </div>
                    <div className="flex gap-4 mt-4">
                      <button onClick={handleApplyChanges} className="w-full bg-brand-green text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-700 transition">Apply Changes</button>
                      <button onClick={() => setOptimizedListing(null)} className="w-full bg-slate-200 text-slate-700 px-4 py-2 rounded-lg font-semibold hover:bg-slate-300 transition">Discard</button>
                    </div>
                 </div>
             ) : (
                <>
                  <button 
                      onClick={handleOptimize}
                      disabled={isOptimizing}
                      className="w-full flex items-center justify-center gap-2 bg-brand-blue text-white px-4 py-3 rounded-lg font-semibold hover:bg-blue-700 transition disabled:bg-blue-300 disabled:cursor-not-allowed"
                  >
                      {isOptimizing ? (
                          <>
                            <LoadingSpinner size="small" />
                            <span>Optimizing...</span>
                          </>
                      ) : (
                          <>
                            <SparklesIcon className="w-5 h-5" />
                            <span>Optimize with Gemini</span>
                          </>
                      )}
                  </button>
                  {optimizationError && <p className="text-red-500 text-sm mt-2 text-center">{optimizationError}</p>}
                </>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};
