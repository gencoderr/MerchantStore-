
import React from 'react';
import { StoreIcon } from './icons/StoreIcon';

export const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <StoreIcon className="w-8 h-8 text-brand-blue" />
          <span className="text-2xl font-semibold text-slate-800">Merchant Assist AI</span>
        </div>
      </div>
    </header>
  );
};
