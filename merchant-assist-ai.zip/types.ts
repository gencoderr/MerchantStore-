
export enum ProductStatus {
  ACTIVE = 'ACTIVE',
  PENDING = 'PENDING',
  DISAPPROVED = 'DISAPPROVED',
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  imageUrl: string;
  status: ProductStatus;
}

export interface OptimizedListing {
  newTitle: string;
  newDescription:string;
}
