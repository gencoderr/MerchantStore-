
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { LoadingSpinner } from './components/LoadingSpinner';
import type { Product } from './types';
import { generateMockProducts } from './services/geminiService';
import { SparklesIcon } from './components/icons/SparklesIcon';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const mockProducts = await generateMockProducts();
      setProducts(mockProducts);
    } catch (e) {
      console.error(e);
      setError('Failed to generate product data. Please check your API key and try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
  };

  const handleCloseModal = () => {
    setSelectedProduct(null);
  };

  const handleProductUpdate = (updatedProduct: Product) => {
    setProducts(prevProducts =>
      prevProducts.map(p => (p.id === updatedProduct.id ? updatedProduct : p))
    );
    setSelectedProduct(updatedProduct);
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center text-center h-64">
          <LoadingSpinner />
          <p className="text-lg text-slate-600 mt-4">Generating realistic product data with Gemini...</p>
          <p className="text-sm text-slate-500">This may take a moment.</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center text-center h-64 bg-red-50 border border-red-200 rounded-lg p-6">
          <p className="text-lg font-semibold text-red-700">An Error Occurred</p>
          <p className="text-slate-600 mt-2">{error}</p>
           <button 
            onClick={fetchProducts}
            className="mt-4 px-4 py-2 bg-brand-blue text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Retry
          </button>
        </div>
      );
    }
    
    if (products.length === 0) {
       return (
        <div className="flex flex-col items-center justify-center text-center h-64">
          <p className="text-lg text-slate-600">No products found.</p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onSelect={() => handleProductSelect(product)}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="flex items-center gap-2 mb-6">
           <SparklesIcon className="w-8 h-8 text-brand-blue"/>
           <h1 className="text-3xl font-bold text-slate-800">AI-Powered Product Dashboard</h1>
        </div>
        {renderContent()}
      </main>
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={handleCloseModal}
          onProductUpdate={handleProductUpdate}
        />
      )}
    </div>
  );
};

export default App;
