
import { GoogleGenAI, Type } from "@google/genai";
import type { Product, OptimizedListing } from '../types';
import { ProductStatus } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const productSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING, description: 'A unique identifier for the product, like a SKU.' },
      title: { type: Type.STRING, description: 'The name of the product.' },
      description: { type: Type.STRING, description: 'A detailed and appealing description of the product.' },
      price: { type: Type.NUMBER, description: 'The price of the product in numbers.' },
      currency: { type: Type.STRING, description: 'The currency code, e.g., USD.' },
      status: {
        type: Type.STRING,
        enum: [ProductStatus.ACTIVE, ProductStatus.PENDING, ProductStatus.DISAPPROVED],
        description: 'The current status of the product listing.',
      },
    },
    required: ['id', 'title', 'description', 'price', 'currency', 'status'],
  },
};

export const generateMockProducts = async (): Promise<Product[]> => {
  const prompt = `Generate a list of 12 realistic but fictional e-commerce products for an online store that sells modern, stylish home goods and decor. Provide varied statuses for the products.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: productSchema,
      },
    });

    const productsData = JSON.parse(response.text) as Omit<Product, 'imageUrl'>[];
    
    // Add placeholder images
    return productsData.map((p, index) => ({
      ...p,
      imageUrl: `https://picsum.photos/seed/${p.id || index}/500/500`,
    }));

  } catch (error) {
    console.error("Error generating mock products:", error);
    throw new Error("Failed to communicate with the Gemini API to generate products.");
  }
};


const optimizationSchema = {
    type: Type.OBJECT,
    properties: {
        newTitle: {
            type: Type.STRING,
            description: 'The optimized product title, concise and SEO-friendly.'
        },
        newDescription: {
            type: Type.STRING,
            description: 'The rewritten product description, engaging and highlighting key benefits.'
        }
    },
    required: ['newTitle', 'newDescription']
};

export const optimizeProductListing = async (product: Product): Promise<OptimizedListing> => {
    const prompt = `You are an expert e-commerce SEO and copywriting specialist.
    Given the following product details, rewrite the title and description to be more engaging, descriptive, and optimized for search engines.
    Focus on benefits for the customer and include relevant keywords naturally.
    
    Current Title: "${product.title}"
    Current Description: "${product.description}"

    Return the result as a JSON object with 'newTitle' and 'newDescription' keys.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: optimizationSchema,
            }
        });

        return JSON.parse(response.text) as OptimizedListing;
    } catch (error) {
        console.error("Error optimizing product listing:", error);
        throw new Error("Failed to communicate with the Gemini API for optimization.");
    }
};
