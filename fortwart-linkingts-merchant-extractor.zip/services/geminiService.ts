import { GoogleGenAI, Type } from "@google/genai";
import type { MerchantInfo } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const merchantResponseSchema = {
  type: Type.OBJECT,
  properties: {
    merchantName: {
      type: Type.STRING,
      description: "The name of the business or merchant.",
    },
    address: {
      type: Type.STRING,
      description: "The full street address of the merchant.",
    },
    phoneNumber: {
      type: Type.STRING,
      description: "The contact phone number of the merchant.",
    },
    website: {
      type: Type.STRING,
      description: "The official website URL of the merchant.",
    },
    category: {
        type: Type.STRING,
        description: "A category for the merchant (e.g., 'Restaurant', 'Retail', 'Service').",
    },
  },
  required: ["merchantName", "address", "phoneNumber", "website", "category"],
};

export const extractMerchantInfo = async (text: string): Promise<MerchantInfo> => {
  const prompt = `
    Analyze the following text and extract the merchant's information based on the provided JSON schema.
    If a specific piece of information is not available in the text, return an empty string for that field.
    
    Text to analyze:
    ---
    ${text}
    ---
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: merchantResponseSchema,
        temperature: 0,
      },
    });

    const responseText = response.text.trim();
    if (!responseText) {
        throw new Error("Received an empty response from the API.");
    }
    
    // Attempt to parse the JSON response
    const parsedData = JSON.parse(responseText);
    
    // Basic validation to ensure it looks like our MerchantInfo object
    if (typeof parsedData.merchantName !== 'string') {
        throw new Error("Invalid data format received from API.");
    }

    return parsedData as MerchantInfo;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof SyntaxError) {
        throw new Error("Failed to parse the data from the AI. The format was invalid.");
    }
    throw new Error("Could not extract merchant information. Please try again or rephrase your input.");
  }
};

const soulCodeResponseSchema = {
    type: Type.OBJECT,
    properties: {
        soulCode: {
            type: Type.STRING,
            description: "The generated code in the esoteric 'Soul' language."
        },
        cppCode: {
            type: Type.STRING,
            description: "A functional, runnable C++ translation of the Soul code."
        }
    },
    required: ["soulCode", "cppCode"]
};

export const generateSoulCode = async (intention: string): Promise<{ soulCode: string; cppCode: string }> => {
    const systemInstruction = `
You are a creative coding assistant that translates a user's intention into two programming languages.
1.  **Soul**: A fictional, poetic, esoteric programming language that uses concepts of emotion and spirit.
2.  **C++**: A practical, high-performance, real-world programming language.

Your task is to generate code for both languages based on the user's request and return them in a JSON object. The C++ code MUST be a direct, functional translation of the Soul code's logic.

**Soul Language Syntax and C++ Mapping:**

*   **Essence**: Represents a core concept or object.
    *   Soul: \`Essence MyConcept { ... }\`
    *   C++: \`class MyConcept { ... };\` or \`struct MyConcept { ... };\`

*   **Flow**: A function or a sequence of actions.
    *   Soul: \`Flow doSomething() { ... }\`
    *   C++: \`void doSomething() { ... }\` or \`returnType doSomething() { ... }\`

*   **Memory\u003CType\u003E**: A variable to hold a memory or value. Types can be \`Number\`, \`String\`, \`Boolean\`.
    *   Soul: \`Memory\u003CString\u003E name;\`
    *   C++: \`std::string name;\` (Remember to include \u003Cstring\u003E), \`int\`, \`double\`, \`bool\`.

*   **Echo(...)**: Prints a message to the console.
    *   Soul: \`Echo("Hello, world.");\`
    *   C++: \`std::cout \u003C\u003C "Hello, world." \u003C\u003C std::endl;\` (Remember to include \u003Ciostream\u003E)

*   **Listen(variable)**: Reads user input into a variable.
    *   Soul: \`Listen(name);\`
    *   C++: \`std::cin >> name;\`

*   **Chime\u003Ccondition\u003E**: A conditional if-statement.
    *   Soul: \`Chime\u003Cvalue \u003E 10\u003E { ... }\`
    *   C++: \`if (value \u003E 10) { ... }\`

*   **Cycle\u003Ccondition\u003E**: A loop.
    *   Soul: \`Cycle\u003Ci \u003C 5\u003E { ... }\`
    *   C++: \`while (i \u003C 5) { ... }\` or a \`for\` loop.

*   **Whisper**: A comment.
    *   Soul: \`Whisper "This is a secret"\`
    *   C++: \`// This is a secret\`

*   **Rift / Mend**: Error handling.
    *   Soul: \`Rift { ... } Mend { ... }\`
    *   C++: \`try { ... } catch (...) { ... }\`

**Example:**
User Intention: "A program that asks for a number and prints if it's positive."

Your JSON output should be:
{
  "soulCode": "Essence NumberReader {\\n  Flow main() {\\n    Echo(\\"Enter a number, and I shall feel its energy.\\");\\n    Memory\u003CNumber\u003E num;\\n    Listen(num);\\n    Chime\u003Cnum \u003E 0\u003E {\\n      Echo(\\"The number's energy is positive.\\");\\n    }\\n  }\\n}",
  "cppCode": "#include \u003Ciostream\u003E\\n\\nclass NumberReader {\\npublic:\\n    void main() {\\n        std::cout \u003C\u003C \\"Enter a number, and I shall feel its energy.\\" \u003C\u003C std::endl;\\n        int num;\\n        std::cin >> num;\\n        if (num \u003E 0) {\\n            std::cout \u003C\u003C \\"The number's energy is positive.\\" \u003C\u003C std::endl;\\n        }\\n    }\\n};\\n\\nint main() {\\n    NumberReader app;\\n    app.main();\\n    return 0;\\n}"
}

**Constraint**: The C++ code must be complete, include necessary headers (like iostream, string, vector), and have a \`main\` function to be runnable.
`;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `User Intention: "${intention}"`,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: soulCodeResponseSchema,
                temperature: 0.2,
            },
        });

        const responseText = response.text.trim();
        if (!responseText) {
            throw new Error("Received an empty response from the API.");
        }

        const parsedData = JSON.parse(responseText);
        if (typeof parsedData.soulCode !== 'string' || typeof parsedData.cppCode !== 'string') {
            throw new Error("Invalid data format received from API.");
        }
        
        return parsedData;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        if (error instanceof SyntaxError) {
            throw new Error("Failed to parse the data from the AI. The format was invalid.");
        }
        throw new Error("Could not generate code. Please try again or rephrase your intention.");
    }
};