
import React, { useState, useCallback, useEffect } from 'react';
import { extractMerchantInfo } from './services/geminiService';
import type { MerchantInfo } from './types';
import MerchantInfoCard from './components/MerchantInfoCard';
import Spinner from './components/Spinner';
import SparklesIcon from './components/icons/SparklesIcon';
import ArchiveBoxIcon from './components/icons/ArchiveBoxIcon';
import BinaryIcon from './components/icons/BinaryIcon';
import CodeBracketSquareIcon from './components/icons/CodeBracketSquareIcon';
import BinaryConverter from './components/BinaryConverter';
import SoulCodeGenerator from './components/SoulCodeGenerator';


interface TabButtonProps {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
  count?: number;
}

const TabButton: React.FC<TabButtonProps> = ({ icon, label, isActive, onClick, count }) => (
  <button
    onClick={onClick}
    className={`flex items-center justify-center gap-2 px-4 py-3 text-sm sm:text-base sm:px-6 font-semibold transition-colors rounded-t-lg -mb-px border-b-2 ${
      isActive
        ? 'text-teal-400 border-teal-400'
        : 'text-gray-500 border-transparent hover:text-gray-300 hover:border-gray-500'
    }`}
    role="tab"
    aria-selected={isActive}
  >
    {icon}
    {label}
    {typeof count !== 'undefined' && (
      <span className={`ml-2 text-xs font-bold px-2 py-0.5 rounded-full ${isActive ? 'bg-teal-400/20 text-teal-300' : 'bg-gray-700 text-gray-300'}`}>
        {count}
      </span>
    )}
  </button>
);


const App: React.FC = () => {
  const [activeView, setActiveView] = useState<'extractor' | 'saved' | 'converter' | 'soulCoder'>('extractor');
  const [inputText, setInputText] = useState<string>('');
  const [extractedData, setExtractedData] = useState<MerchantInfo | null>(null);
  const [savedMerchants, setSavedMerchants] = useState<MerchantInfo[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    try {
      const storedMerchants = localStorage.getItem('savedMerchants');
      if (storedMerchants) {
        setSavedMerchants(JSON.parse(storedMerchants));
      }
    } catch (e) {
      console.error("Failed to load merchants from localStorage", e);
      localStorage.removeItem('savedMerchants');
    }
  }, []);

  const handleExtract = useCallback(async () => {
    if (!inputText.trim()) {
      setError('Please paste some text to analyze.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setExtractedData(null);

    try {
      const data = await extractMerchantInfo(inputText);
      setExtractedData(data);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [inputText]);
  
  const handleSaveMerchant = (merchantData: MerchantInfo) => {
    const isDuplicate = savedMerchants.some(m => m.merchantName === merchantData.merchantName && m.address === merchantData.address);

    if(isDuplicate) {
      setError("This merchant appears to be already saved.");
      setTimeout(() => setError(null), 3000);
      return;
    }

    const newMerchant = { ...merchantData, id: `merchant_${Date.now()}` };
    const updatedMerchants = [newMerchant, ...savedMerchants];
    setSavedMerchants(updatedMerchants);
    localStorage.setItem('savedMerchants', JSON.stringify(updatedMerchants));

    setExtractedData(null);
    setShowSaveSuccess(true);
    setTimeout(() => setShowSaveSuccess(false), 2500);
  };

  const handleDeleteMerchant = (idToDelete: string) => {
    const updatedMerchants = savedMerchants.filter(m => m.id !== idToDelete);
    setSavedMerchants(updatedMerchants);
    localStorage.setItem('savedMerchants', JSON.stringify(updatedMerchants));
  };
  
  const exampleText = `Received from The Coffee Bean, 123 Main Street, Anytown, CA 90210. Phone: 555-123-4567. Check them out online at www.coffeebean.example.com. Total: $5.75`;
  
  const filteredMerchants = savedMerchants.filter(merchant => 
    merchant.merchantName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    merchant.address?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    merchant.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 sm:p-6 font-sans">
      <div className="w-full max-w-3xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-500">
            Omni Tools
          </h1>
          <p className="text-gray-400 mt-2">
            A suite of powerful AI-driven utilities.
          </p>
        </header>

        {showSaveSuccess && (
          <div className="fixed top-5 right-5 bg-green-600 text-white px-4 py-2 rounded-lg shadow-lg animate-fade-in-out z-50">
            Merchant saved successfully!
          </div>
        )}

        <div className="mb-8 flex justify-center border-b border-gray-700 flex-wrap">
          <TabButton icon={<SparklesIcon />} label="Extractor" isActive={activeView === 'extractor'} onClick={() => setActiveView('extractor')} />
          <TabButton icon={<ArchiveBoxIcon />} label="Saved" count={savedMerchants.length} isActive={activeView === 'saved'} onClick={() => setActiveView('saved')} />
          <TabButton icon={<BinaryIcon />} label="Binary Tools" isActive={activeView === 'converter'} onClick={() => setActiveView('converter')} />
          <TabButton icon={<CodeBracketSquareIcon />} label="Soul Coder" isActive={activeView === 'soulCoder'} onClick={() => setActiveView('soulCoder')} />
        </div>

        <main>
          {activeView === 'extractor' && (
            <>
              <div className="bg-gray-800 rounded-lg shadow-2xl p-6 mb-8">
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Paste receipt text, email confirmations, or any relevant text here..."
                  className="w-full h-48 p-4 bg-gray-900 border-2 border-gray-700 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all text-gray-200 resize-none"
                  disabled={isLoading}
                />
                <div className="flex justify-between items-center mt-4">
                  <button
                    onClick={() => setInputText(exampleText)}
                    className="text-sm text-teal-400 hover:text-teal-300 transition-colors"
                    disabled={isLoading}
                  >
                    Load Example
                  </button>
                  <button
                    onClick={handleExtract}
                    disabled={isLoading || !inputText.trim()}
                    className="flex items-center justify-center px-6 py-3 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-semibold rounded-lg shadow-md hover:from-teal-600 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-teal-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? (
                      <>
                        <Spinner />
                        Extracting...
                      </>
                    ) : (
                      'Extract Information'
                    )}
                  </button>
                </div>
              </div>

              <div className="mt-6">
                {error && (
                  <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg" role="alert">
                    <strong className="font-bold">Error: </strong>
                    <span className="block sm:inline">{error}</span>
                  </div>
                )}

                {extractedData && !isLoading && (
                  <MerchantInfoCard data={extractedData} onSave={handleSaveMerchant} />
                )}

                {!extractedData && !isLoading && !error && (
                  <div className="text-center text-gray-500 py-10 px-4 border-2 border-dashed border-gray-700 rounded-lg">
                    <p className="text-lg">Your extracted information will appear here.</p>
                  </div>
                )}
              </div>
            </>
          )}

          {activeView === 'saved' && (
             <div className="animate-fade-in">
                <input
                    type="search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by name, address, or category..."
                    className="w-full p-4 bg-gray-800 border-2 border-gray-700 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all text-gray-200 mb-6"
                />
                {savedMerchants.length > 0 ? (
                    <div className="space-y-6">
                    {filteredMerchants.length > 0 ? (
                         filteredMerchants.map(merchant => (
                            <MerchantInfoCard key={merchant.id} data={merchant} onDelete={handleDeleteMerchant} />
                        ))
                    ) : (
                        <div className="text-center text-gray-500 py-10 px-4 border-2 border-dashed border-gray-700 rounded-lg">
                            <p className="text-lg">No merchants found for your search.</p>
                        </div>
                    )}
                    </div>
                ) : (
                    <div className="text-center text-gray-500 py-10 px-4 border-2 border-dashed border-gray-700 rounded-lg">
                        <p className="text-lg">You haven't saved any merchants yet.</p>
                        <p className="mt-2 text-sm">Use the "Extractor" tab to get started.</p>
                    </div>
                )}
             </div>
          )}

          {activeView === 'converter' && <BinaryConverter />}
          {activeView === 'soulCoder' && <SoulCodeGenerator />}
        </main>
        
        <footer className="text-center text-gray-600 mt-12 py-4">
            <p>Powered by Google Gemini</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
