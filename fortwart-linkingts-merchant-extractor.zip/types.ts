
export interface MerchantInfo {
  id?: string; // Will be added when saved
  merchantName: string;
  address: string;
  phoneNumber: string;
  website: string;
  category: string;
}
