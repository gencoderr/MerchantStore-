import React, { useState } from 'react';
import ClipboardIcon from './icons/ClipboardIcon';
import XCircleIcon from './icons/XCircleIcon';

const BinaryConverter: React.FC = () => {
    const [textValue, setTextValue] = useState('');
    const [binaryValue, setBinaryValue] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [showTextCopied, setShowTextCopied] = useState(false);
    const [showBinaryCopied, setShowBinaryCopied] = useState(false);

    const convertTextToBinary = (text: string): string => {
        if (!text) return '';
        return text
            .split('')
            .map(char => char.charCodeAt(0).toString(2).padStart(8, '0'))
            .join(' ');
    };

    const convertBinaryToText = (binary: string): string => {
        setError(null);
        if (!binary) return '';
        
        const cleanBinary = binary.replace(/\s/g, '');
        if (/[^01]/.test(cleanBinary)) {
            setError('Invalid input: Binary code must contain only 0s and 1s.');
            return textValue; // Return previous valid text
        }

        const bytes = cleanBinary.match(/.{1,8}/g);
        if (!bytes) {
            return '';
        }

        let result = '';
        let partialByte = false;

        bytes.forEach(byte => {
            if (byte.length === 8) {
                result += String.fromCharCode(parseInt(byte, 2));
            } else {
                partialByte = true;
            }
        });
        
        if (partialByte) {
            setError('Warning: Input contains an incomplete byte. Only full 8-bit bytes were converted.');
        }

        return result;
    };

    const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const newText = e.target.value;
        setTextValue(newText);
        setBinaryValue(convertTextToBinary(newText));
        if (error) setError(null);
    };

    const handleBinaryChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const newBinary = e.target.value;
        setBinaryValue(newBinary);
        setTextValue(convertBinaryToText(newBinary));
    };
    
    const handleClear = () => {
        setTextValue('');
        setBinaryValue('');
        setError(null);
    };

    const handleCopyToClipboard = (type: 'text' | 'binary') => {
        if (type === 'text' && textValue) {
            navigator.clipboard.writeText(textValue);
            setShowTextCopied(true);
            setTimeout(() => setShowTextCopied(false), 2000);
        } else if (type === 'binary' && binaryValue) {
            navigator.clipboard.writeText(binaryValue);
            setShowBinaryCopied(true);
            setTimeout(() => setShowBinaryCopied(false), 2000);
        }
    };

    return (
        <div className="animate-fade-in bg-gray-800 rounded-lg shadow-2xl p-6">
            <h2 className="text-2xl font-bold text-center mb-6 text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-500">
                Binary Tools
            </h2>
            <div className="flex flex-col md:flex-row items-start gap-6">
                {/* Text Area */}
                <div className="w-full">
                    <label htmlFor="text-input" className="block text-sm font-medium text-gray-400 mb-2">
                        Text
                    </label>
                    <div className="relative">
                        <textarea
                            id="text-input"
                            value={textValue}
                            onChange={handleTextChange}
                            placeholder="Type or paste text here..."
                            className="w-full h-48 p-4 bg-gray-900 border-2 border-gray-700 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all text-gray-200 resize-y"
                        />
                         <button
                            onClick={() => handleCopyToClipboard('text')}
                            disabled={!textValue}
                            title="Copy text"
                            className="absolute top-2 right-2 flex items-center justify-center w-20 p-2 text-xs bg-gray-700/80 hover:bg-gray-600 text-white font-semibold rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {showTextCopied ? 'Copied!' : <ClipboardIcon />}
                        </button>
                    </div>
                </div>
                
                {/* Binary Area */}
                <div className="w-full">
                    <label htmlFor="binary-output" className="block text-sm font-medium text-gray-400 mb-2">
                        Binary
                    </label>
                    <div className="relative">
                        <textarea
                            id="binary-output"
                            value={binaryValue}
                            onChange={handleBinaryChange}
                            placeholder="01101000 01100101 01101100 01101100 01101111"
                            className={`w-full h-48 p-4 bg-gray-900 border-2 rounded-md focus:ring-2 transition-all resize-y font-mono ${error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-700 focus:ring-teal-500 focus:border-teal-500'}`}
                            aria-invalid={!!error}
                            aria-describedby="binary-error"
                        />
                        <button
                            onClick={() => handleCopyToClipboard('binary')}
                            disabled={!binaryValue}
                            title="Copy binary code"
                            className="absolute top-2 right-2 flex items-center justify-center w-20 p-2 text-xs bg-gray-700/80 hover:bg-gray-600 text-white font-semibold rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                           {showBinaryCopied ? 'Copied!' : <ClipboardIcon />}
                        </button>
                    </div>
                     {error && <p id="binary-error" className="text-xs text-red-400 mt-2">{error}</p>}
                </div>
            </div>
            <div className="flex justify-center items-center mt-6">
                <button
                    onClick={handleClear}
                    disabled={!textValue && !binaryValue}
                    className="flex items-center gap-2 px-6 py-3 text-sm text-gray-300 hover:text-white bg-gray-700 hover:bg-gray-600 font-semibold rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <XCircleIcon />
                    Clear All
                </button>
            </div>
        </div>
    );
};

export default BinaryConverter;