
import React, { useState, useCallback } from 'react';
import { generateSoulCode } from '../services/geminiService';
import Spinner from './Spinner';
import ClipboardIcon from './icons/ClipboardIcon';

const SoulCodeGenerator: React.FC = () => {
  const [intention, setIntention] = useState<string>('');
  const [generatedCode, setGeneratedCode] = useState<{ soulCode: string; cppCode: string } | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'soul' | 'cpp'>('soul');
  const [showCopied, setShowCopied] = useState(false);

  const handleGenerate = useCallback(async () => {
    if (!intention.trim()) {
      setError('Please describe what you want the code to do.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedCode(null);

    try {
      const data = await generateSoulCode(intention);
      setGeneratedCode(data);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred during code generation.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [intention]);

  const handleCopy = () => {
    if (!generatedCode) return;
    const codeToCopy = activeTab === 'soul' ? generatedCode.soulCode : generatedCode.cppCode;
    navigator.clipboard.writeText(codeToCopy);
    setShowCopied(true);
    setTimeout(() => setShowCopied(false), 2000);
  };
  
  const exampleText = `Create a program that asks for the user's name and greets them.`;

  return (
    <div className="animate-fade-in">
      <div className="bg-gray-800 rounded-lg shadow-2xl p-6 mb-8">
        <h2 className="text-2xl font-bold text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-500">
          Soul to C++ Converter
        </h2>
        <p className="text-center text-gray-400 mb-6">
          Describe your intention and watch AI translate it into poetic Soul and functional C++.
        </p>
        <textarea
          value={intention}
          onChange={(e) => setIntention(e.target.value)}
          placeholder="e.g., A program that counts from 1 to 10..."
          className="w-full h-32 p-4 bg-gray-900 border-2 border-gray-700 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all text-gray-200 resize-none"
          disabled={isLoading}
        />
        <div className="flex justify-between items-center mt-4">
            <button
                onClick={() => setIntention(exampleText)}
                className="text-sm text-teal-400 hover:text-teal-300 transition-colors"
                disabled={isLoading}
            >
                Load Example
            </button>
          <button
            onClick={handleGenerate}
            disabled={isLoading || !intention.trim()}
            className="flex items-center justify-center px-6 py-3 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-semibold rounded-lg shadow-md hover:from-teal-600 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-teal-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <Spinner />
                Generating...
              </>
            ) : (
              'Generate Code'
            )}
          </button>
        </div>
      </div>

      <div className="mt-6">
        {error && (
          <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        {generatedCode && !isLoading && (
          <div className="bg-gray-800 rounded-lg shadow-2xl animate-fade-in">
            <div className="flex border-b border-gray-700 relative">
              <button
                onClick={() => setActiveTab('soul')}
                className={`px-6 py-3 font-semibold transition-colors ${activeTab === 'soul' ? 'text-teal-400 border-b-2 border-teal-400' : 'text-gray-400 hover:text-white'}`}
              >
                Soul
              </button>
              <button
                onClick={() => setActiveTab('cpp')}
                className={`px-6 py-3 font-semibold transition-colors ${activeTab === 'cpp' ? 'text-teal-400 border-b-2 border-teal-400' : 'text-gray-400 hover:text-white'}`}
              >
                C++
              </button>
              <button
                onClick={handleCopy}
                className="absolute top-1/2 right-3 -translate-y-1/2 flex items-center justify-center w-24 p-2 text-xs bg-gray-700/80 hover:bg-gray-600 text-white font-semibold rounded-lg transition-all"
              >
                {showCopied ? 'Copied!' : <><ClipboardIcon /> <span className="ml-1">Copy</span></>}
              </button>
            </div>
            <pre className="p-4 overflow-x-auto">
              <code className="text-sm text-gray-200 whitespace-pre-wrap font-mono">
                {activeTab === 'soul' ? generatedCode.soulCode : generatedCode.cppCode}
              </code>
            </pre>
          </div>
        )}

        {!generatedCode && !isLoading && !error && (
          <div className="text-center text-gray-500 py-10 px-4 border-2 border-dashed border-gray-700 rounded-lg">
            <p className="text-lg">Your generated code will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SoulCodeGenerator;
