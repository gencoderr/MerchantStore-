
import React from 'react';
import type { MerchantInfo } from '../types';
import BuildingIcon from './icons/BuildingIcon';
import GlobeIcon from './icons/GlobeIcon';
import MapPinIcon from './icons/MapPinIcon';
import PhoneIcon from './icons/PhoneIcon';
import TagIcon from './icons/TagIcon';
import SaveIcon from './icons/SaveIcon';
import TrashIcon from './icons/TrashIcon';

interface MerchantInfoCardProps {
  data: MerchantInfo;
  onSave?: (data: MerchantInfo) => void;
  onDelete?: (id: string) => void;
}

const InfoRow: React.FC<{ icon: React.ReactNode; label: string; value: string | undefined }> = ({ icon, label, value }) => {
  const displayValue = value && value.trim() ? value : 'Not found';
  const isLink = value && (value.startsWith('http') || value.startsWith('www'));

  return (
    <div className="flex items-start py-4 border-b border-gray-700 last:border-b-0">
      <div className="flex-shrink-0 w-8 h-8 text-teal-400">{icon}</div>
      <div className="ml-4 flex-1 min-w-0">
        <p className="text-sm text-gray-400">{label}</p>
        {isLink ? (
           <a href={value.startsWith('http') ? value : `//${value}`} target="_blank" rel="noopener noreferrer" className="text-lg font-medium text-blue-400 hover:underline break-words">
             {displayValue}
           </a>
        ) : (
           <p className={`text-lg font-medium break-words ${!value || !value.trim() ? 'text-gray-500 italic' : 'text-gray-100'}`}>{displayValue}</p>
        )}
      </div>
    </div>
  );
};

const MerchantInfoCard: React.FC<MerchantInfoCardProps> = ({ data, onSave, onDelete }) => {
  const isSavedCard = !!onDelete;

  return (
    <div className="bg-gray-800 rounded-lg shadow-2xl animate-fade-in relative group">
      {isSavedCard && data.id && (
        <button
          onClick={() => onDelete(data.id!)}
          className="absolute top-3 right-3 text-gray-500 hover:text-red-400 transition-all p-2 rounded-full bg-gray-900/50 hover:bg-gray-900 opacity-0 group-hover:opacity-100 focus:opacity-100"
          aria-label="Delete merchant"
        >
          <TrashIcon />
        </button>
      )}

      <div className="p-6 bg-gray-800/50 rounded-t-lg">
          <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-500 pr-10">
              {isSavedCard ? data.merchantName || 'Unnamed Merchant' : 'Extracted Information'}
          </h2>
      </div>

      <div className="px-6 pb-6">
          {!isSavedCard && <InfoRow icon={<BuildingIcon />} label="Merchant Name" value={data.merchantName} />}
          <InfoRow icon={<MapPinIcon />} label="Address" value={data.address} />
          <InfoRow icon={<PhoneIcon />} label="Phone Number" value={data.phoneNumber} />
          <InfoRow icon={<GlobeIcon />} label="Website" value={data.website} />
          <InfoRow icon={<TagIcon />} label="Category" value={data.category} />
      </div>

      {onSave && (
        <div className="px-6 py-4 bg-gray-900/50 rounded-b-lg border-t border-gray-700">
          <button
            onClick={() => onSave(data)}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-teal-500 transition-all"
          >
            <SaveIcon />
            Save Merchant
          </button>
        </div>
      )}
    </div>
  );
};

export default MerchantInfoCard;
