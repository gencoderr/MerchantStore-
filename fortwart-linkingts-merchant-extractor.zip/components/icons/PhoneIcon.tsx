
import React from 'react';

const PhoneIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-full h-full">
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.211-.992-.58-1.355l-3.114-3.114a1.125 1.125 0 0 0-1.591 0L14.25 12.75a.75.75 0 0 1-1.06 0l-2.829-2.828a.75.75 0 0 1 0-1.06l1.3-1.302a1.125 1.125 0 0 0 0-1.591l-3.114-3.114A2.25 2.25 0 0 0 4.5 3.75H2.25A2.25 2.25 0 0 0 0 6.75v.75Z" />
  </svg>
);

export default PhoneIcon;
