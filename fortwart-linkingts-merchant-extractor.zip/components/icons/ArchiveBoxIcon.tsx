
import React from 'react';

const ArchiveBoxIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 sm:w-6 sm:h-6">
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.03 1.125 0 1.131.094 1.976 1.057 1.976 2.192V7.5m-9 7.5h18M3.75 12H20.25m-16.5 0V6.22c0-.657.262-1.28.732-1.75.47-.47 1.093-.732 1.75-.732h9.04c.657 0 1.28.262 1.75.732.47.47.732 1.093.732 1.75V12m-16.5 0v6.75A2.25 2.25 0 0 0 6 21h12a2.25 2.25 0 0 0 2.25-2.25V12" />
    </svg>
);

export default ArchiveBoxIcon;
