
import React from 'react';

const GlobeIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-full h-full">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 0 1-9-9 9 9 0 0 1 9-9 9 9 0 0 1 9 9 9 9 0 0 1-9 9Zm0 0a8.949 8.949 0 0 0 4.95-1.742m-9.9 0A8.949 8.949 0 0 0 12 21Zm0-18a8.949 8.949 0 0 0-4.95 1.742m9.9 0A8.949 8.949 0 0 0 12 3Zm0 18.01a9 9 0 0 0 0-18.02" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12h19.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.01 9.01 0 0 1-8.995-9.01M3.005 12A9.01 9.01 0 0 1 12 2.99" />
  </svg>
);

export default GlobeIcon;
