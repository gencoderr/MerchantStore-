# TF SIG Build Dockerfiles (MOVED TO TENSORFLOW REPOSITORY)

These Dockerfiles have been moved inside the main TensorFlow repository.
See: https://github.com/tensorflow/tensorflow/tree/master/tensorflow/tools/tf_sig_build_dockerfiles
